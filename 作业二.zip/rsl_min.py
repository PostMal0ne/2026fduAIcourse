#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
作业二（最小版）：一个简单的 RSL（Recursive Self-Learning）系统
=================================================================
只用 Python 标准库，不需要 pip 安装任何东西。

系统结构：
    任务集(有标准答案) → 策略(UCB1 老虎机) → 执行(本地 Ollama，可多个模型)
        → 评判(机器判分) → 经验库(SQLite) → 策略更新 → 在保留集上复测

为什么这样设计（都是在本机实测踩出来的结论，不是想当然）：
  1. 任务答案由程序生成、唯一正确 → 判分不依赖 LLM 裁判，杜绝 reward hacking。
  2. 训练集与保留集严格分离 → 用没见过的题证明是否真的变好。
  3. 必须和 baseline 对比（随机选臂 / 固定最优臂）→ 证明"学过之后比不学好"。
  4. ★ 臂 = 「用哪个模型 + 用什么提示策略」→ 这就是模型路由问题，和课程
     ModelRouter 的主题一致；一个强模型 + 一个弱模型，差距是结构性的。
  5. ★ 不要传 "think": false。qwen3 这类带思考的模型会先把 token 花在思考上，
     传 false 反而让思考混进正文；不传该字段时思考会进独立的 thinking 字段被自动
     丢弃，正文就是干净答案。同时 num_predict 必须给足（默认 1792）。
  6. ★ 不要让提示词要求模型"先逐步推理"：实测会让 qwen3 陷入自我循环，
     把 token 预算烧光且不给答案（done_reason=length、response 为空）。

用法：
    # 0) 先拉一个弱模型（约 0.5GB），制造"该选谁"的学习空间
    ollama pull qwen3:0.6b

    # 1) 先用模拟模型验证脚本本身能跑（1 分钟，不出网）
    python rsl_min.py --mock

    # 2) 真跑（默认配置约 8–15 分钟）
    python rsl_min.py --model qwen3:4b

    # 3) 想跑久一点、证据更充分
    python rsl_min.py --model qwen3:4b --rounds 6 --samples 6 --n-test 10

产出：
    results.md     学习曲线 + baseline 对比 + 结论（可直接放进报告）
    curve.svg      在线累计准确率随轮次上升的曲线（可插进报告）
    experience.db  经验库（SQLite，含每次决策、得分、耗时、回答片段）
"""

import argparse
import json
import math
import os
import random
import re
import sqlite3
import statistics
import sys
import time
import urllib.error
import urllib.request

NUM_RE = re.compile(r"-?\d+(?:\.\d+)?")
ANSWER_RE = re.compile(r"答案\s*[:：]?\s*(-?\d+(?:\.\d+)?|[A-Za-z0-9\-]+)")


# ----------------------------------------------------------------------------
# 1. 任务集：程序生成，标准答案由 Python 算出来（因此绝对可靠）
# ----------------------------------------------------------------------------
def build_tasks(seed: int, n_train: int, n_test: int):
    rng = random.Random(seed)
    tasks = []

    def add(kind, question, answer):
        tasks.append({"id": len(tasks), "kind": kind, "question": question, "answer": str(answer)})

    kinds = 7
    for i in range(n_train + n_test):
        k = i % kinds
        if k == 0:  # 三位数乘两位数（较难，能拉开大小模型的差距）
            a, b = rng.randint(100, 999), rng.randint(13, 99)
            add("multiply", f"计算 {a} × {b} = ?", a * b)
        elif k == 1:  # 多步混合运算
            a, b = rng.randint(100, 999), rng.randint(13, 99)
            c = rng.randint(100, 999)
            add("mixed", f"计算 {a} × {b} + {c} = ?", a * b + c)
        elif k == 2:  # 百分比（结果带小数）
            base = rng.randrange(1000, 9999)
            p = rng.choice([7, 13, 17, 23, 29, 37])
            add("percent", f"计算 {base} 的 {p}% 是多少？", round(base * p / 100, 2))
        elif k == 3:  # 单位换算（带两位小数）
            km = rng.randint(1001, 99999) / 100.0
            add("unit", f"{km} 千米等于多少米？", int(round(km * 1000)))
        elif k == 4:  # 逆运算推理
            b, c, a = rng.randint(50, 200), rng.randint(3, 9), rng.randint(50, 500)
            add("logic", f"一个数加上 {a} 后，等于 {b} 的 {c} 倍。这个数是多少？", b * c - a)
        elif k == 5:  # 两步应用题（打折再涨价，带小数）
            price = rng.randrange(60, 600, 10)
            d = rng.choice([0.8, 0.75, 0.9, 0.65])
            add("word", f"一件商品原价 {price} 元，先打 {d * 10:g} 折，再涨价 10%，最终价格是多少元？",
                round(price * d * 1.1, 2))
        else:  # 字符串抽取（较易）
            oid = f"{rng.choice(['AB', 'CD', 'XZ'])}-2026-{rng.randint(1000, 9999)}"
            add("extract", f'从下面这段文本中提取订单号（只输出订单号）：\n"客户备注：请尽快安排发货，订单号 {oid}，谢谢。"', oid)

    return tasks[:n_train], tasks[n_train:n_train + n_test]


DIRECT = "{q}\n请直接给出最终答案。最后一行必须是：答案：<结果>"
VERIFY = "{q}\n请先给出初步答案，再用一两句话验算一遍；若发现错误就更正。最后一行必须是：答案：<结果>"

ARMS = [
    {
        "name": "strong",
        "desc": "强模型 qwen3:4b + 直接作答",
        "model": "qwen3:4b",
        "temperature": 0.0,
        "template": DIRECT,
    },
    {
        "name": "weak",
        "desc": "弱模型 qwen3:0.6b + 直接作答",
        "model": "qwen3:0.6b",
        "temperature": 0.0,
        "template": DIRECT,
    },
    {
        "name": "strong-verify",
        "desc": "强模型 qwen3:4b + 先答后验算",
        "model": "qwen3:4b",
        "temperature": 0.0,
        "template": VERIFY,
    },
]


# ----------------------------------------------------------------------------
# 2. 执行层：调用本地 Ollama
# ----------------------------------------------------------------------------
class OllamaModel:
    """真模型：调用本地 Ollama 的 /api/generate。"""

    def __init__(self, base_url: str, model: str, num_ctx: int, num_predict: int,
                 temperature: float = 0.0, timeout: int = 900):
        self.url = base_url.rstrip("/") + "/api/generate"
        self.model = model
        self.num_ctx = num_ctx
        self.num_predict = num_predict
        self.temperature = temperature
        self.timeout = timeout

    def generate(self, prompt: str) -> str:
        payload = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "options": {"temperature": self.temperature, "num_ctx": self.num_ctx,
                        "num_predict": self.num_predict},
        }
        req = urllib.request.Request(self.url, data=json.dumps(payload).encode("utf-8"),
                                     headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=self.timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        text = data.get("response") or ""
        if "</think>" in text:            # 兜底：万一思考混进正文就剥掉
            text = text.split("</think>", 1)[1]
        return text.strip() or (data.get("thinking") or "").strip()


class MockModel:
    """模拟模型：不需要 Ollama，用来验证整个流程（各臂准确率不同，便于演示"学会"）。"""

    ACC = {("strong", "multiply"): 0.85, ("weak", "multiply"): 0.25, ("strong-verify", "multiply"): 0.90,
           ("strong", "mixed"): 0.60, ("weak", "mixed"): 0.10, ("strong-verify", "mixed"): 0.70,
           ("strong", "percent"): 0.75, ("weak", "percent"): 0.15, ("strong-verify", "percent"): 0.80,
           ("strong", "unit"): 0.90, ("weak", "unit"): 0.40, ("strong-verify", "unit"): 0.90,
           ("strong", "logic"): 0.65, ("weak", "logic"): 0.20, ("strong-verify", "logic"): 0.75,
           ("strong", "word"): 0.70, ("weak", "word"): 0.15, ("strong-verify", "word"): 0.80,
           ("strong", "extract"): 0.95, ("weak", "extract"): 0.60, ("strong-verify", "extract"): 0.95}

    def __init__(self, seed: int = 7):
        self.rng = random.Random(seed)
        self._arm = "strong"
        self._task = None
        self.temperature = 0.0

    def bind(self, arm_name: str, task: dict):
        self._arm, self._task = arm_name, task

    def generate(self, prompt: str) -> str:
        time.sleep(0.02)
        acc = self.ACC.get((self._arm, self._task["kind"]), 0.5)
        gold = self._task["answer"]
        if self.rng.random() < acc:
            return f"推理略。\n答案：{gold}"
        wrong = str(int(gold) + 7) if gold.lstrip("-").isdigit() else "AA-2026-0000"
        return f"推理略。\n答案：{wrong}"


# ----------------------------------------------------------------------------
# 3. 评判层：机器判分（有标准答案，不依赖 LLM 裁判）
# ----------------------------------------------------------------------------
def judge(task: dict, response: str) -> float:
    text = (response or "").strip()
    if not text:
        return 0.0
    gold = task["answer"]

    if task["kind"] == "extract":
        return 1.0 if gold.lower() in text.lower().replace(" ", "") else 0.0

    matches = ANSWER_RE.findall(text)
    if matches:
        cand = matches[-1]          # 取最后一个「答案：」，兼容"先答后验算再更正"的臂
    else:
        # 只有回答很短时才退回「取最后一个数字」，否则长推理里的数字会造成假阳性
        if len(text) > 300:
            return 0.0
        nums = NUM_RE.findall(text)
        if not nums:
            return 0.0
        cand = nums[-1]
    try:
        got, want = float(cand), float(gold)
    except ValueError:
        return 0.0
    return 1.0 if abs(got - want) <= max(1e-6, abs(want) * 1e-6) else 0.0


# ----------------------------------------------------------------------------
# 4. 策略层：UCB1 多臂老虎机（RSL 的"自我更新"部分）
# ----------------------------------------------------------------------------
class UCB1:
    def __init__(self, arms, c: float = 1.2):
        self.arms = arms
        self.c = c
        self.n = {a["name"]: 0 for a in arms}
        self.s = {a["name"]: 0.0 for a in arms}
        self.total = 0

    def choose(self) -> str:
        for a in self.arms:                       # 每臂先拉一次
            if self.n[a["name"]] == 0:
                return a["name"]
        scores = {}
        for a in self.arms:
            name = a["name"]
            mean = self.s[name] / self.n[name]
            bonus = self.c * (2.0 * math.log(self.total) / self.n[name]) ** 0.5
            scores[name] = mean + bonus
        return max(scores, key=scores.get)

    def update(self, arm: str, reward: float):
        self.n[arm] += 1
        self.s[arm] += reward
        self.total += 1

    def best(self) -> str:
        return max(self.arms, key=lambda a: (self.s[a["name"]] / self.n[a["name"]]) if self.n[a["name"]] else -1)["name"]

    def mean(self, arm: str) -> float:
        return self.s[arm] / self.n[arm] if self.n[arm] else 0.0


# ----------------------------------------------------------------------------
# 5. 经验库
# ----------------------------------------------------------------------------
def open_db(path: str) -> sqlite3.Connection:
    con = sqlite3.connect(path)
    con.execute("""CREATE TABLE IF NOT EXISTS experience (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        round INTEGER, task_id INTEGER, kind TEXT, arm TEXT, model TEXT, score REAL,
        latency_s REAL, response TEXT, ts TEXT)""")
    con.commit()
    return con


# ----------------------------------------------------------------------------
# 6. 主循环：训练(带探索) + 保留集复测 + baseline 对比
# ----------------------------------------------------------------------------
def evaluate(models, default_model: str, arm: dict, tasks, mock: bool):
    """用指定臂在给定题目上贪心评估（不探索）。"""
    model = models.get(arm.get("model", default_model))
    model.temperature = arm.get("temperature", 0.0)
    correct = 0
    for t in tasks:
        if mock:
            model.bind(arm["name"], t)
        out = model.generate(arm["template"].format(q=t["question"]))
        correct += judge(t, out)
    return correct / len(tasks)


def available_models(base_url: str):
    try:
        with urllib.request.urlopen(base_url.rstrip("/") + "/api/tags", timeout=10) as resp:
            return [m.get("name", "") for m in json.loads(resp.read().decode("utf-8")).get("models", [])]
    except Exception:  # noqa: BLE001
        return []


def main():
    ap = argparse.ArgumentParser(description="最小 RSL 系统（UCB1 + 机器判分 + 经验库 + 多模型路由）")
    ap.add_argument("--model", default="qwen3:4b", help="默认模型名")
    ap.add_argument("--base-url", default="http://127.0.0.1:11434")
    ap.add_argument("--rounds", type=int, default=4, help="学习轮次")
    ap.add_argument("--samples", type=int, default=5, help="每轮训练样本数")
    ap.add_argument("--n-train", type=int, default=24)
    ap.add_argument("--n-test", type=int, default=8)
    ap.add_argument("--seed", type=int, default=20260930)
    ap.add_argument("--num-ctx", type=int, default=4096)
    ap.add_argument("--num-predict", type=int, default=1792, help="要留足 token 给思考过程，否则答案会被截断")
    ap.add_argument("--outdir", default=".")
    ap.add_argument("--mock", action="store_true", help="用模拟模型跑通全流程（不需要 Ollama）")
    args = ap.parse_args()

    os.makedirs(args.outdir, exist_ok=True)
    train, test = build_tasks(args.seed, args.n_train, args.n_test)
    rng = random.Random(args.seed + 1)
    model_names = sorted({a.get("model", args.model) for a in ARMS})

    if args.mock:
        mock_model = MockModel(seed=args.seed)
        models = {n: mock_model for n in model_names}
        print("[模式] 模拟模型（仅验证流程；报告里请换成真实运行结果）")
    else:
        models = {n: OllamaModel(args.base_url, n, args.num_ctx, args.num_predict) for n in model_names}
        print(f"[模式] 真实模型 @ {args.base_url}：{', '.join(model_names)}")
        try:
            models[args.model].generate("回答一个字：好")
        except (urllib.error.URLError, OSError) as exc:
            print(f"!! 连不上 Ollama：{exc}\n   请先打开 Ollama 应用，或加 --mock 先验证脚本。")
            return 2
        have = available_models(args.base_url)
        missing = [n for n in model_names if not any(h == n or h.startswith(n + ":") or h.split(":")[0] == n for h in have)]
        if missing:
            print("!! 缺少模型：" + ", ".join(missing))
            for n in missing:
                print(f"   请先运行： ollama pull {n}")
            print("   （弱模型约 0.5GB、强模型约 2.5GB）")
            return 3

    con = open_db(os.path.join(args.outdir, "experience.db"))
    policy = UCB1(ARMS)
    history, arm_use = [], {a["name"]: 0 for a in ARMS}
    rewards_seen, t0 = [], time.time()

    for rnd in range(1, args.rounds + 1):
        batch = rng.sample(train, min(args.samples, len(train)))
        for t in batch:
            arm_name = policy.choose()
            cfg = next(a for a in ARMS if a["name"] == arm_name)
            model = models.get(cfg.get("model", args.model))
            model.temperature = cfg.get("temperature", 0.0)
            if args.mock:
                model.bind(arm_name, t)
            t_start = time.time()
            out = model.generate(cfg["template"].format(q=t["question"]))
            dt = time.time() - t_start
            reward = judge(t, out)
            policy.update(arm_name, reward)
            arm_use[arm_name] += 1
            rewards_seen.append(reward)
            con.execute("""INSERT INTO experience
                (round,task_id,kind,arm,model,score,latency_s,response,ts) VALUES (?,?,?,?,?,?,?,?,?)""",
                        (rnd, t["id"], t["kind"], arm_name, cfg.get("model", args.model), reward,
                         round(dt, 2), out[:200], time.strftime("%Y-%m-%d %H:%M:%S")))
        con.commit()
        best = next(a for a in ARMS if a["name"] == policy.best())
        acc = evaluate(models, args.model, best, test, args.mock)
        history.append({"round": rnd, "best_arm": best["name"], "heldout_acc": acc,
                        "online_cum": statistics.mean(rewards_seen),
                        "pulls": len(rewards_seen)})
        print(f"轮次 {rnd}/{args.rounds}: 最佳臂={best['name']:13s} 保留集={acc:.1%} "
              f"在线累计={history[-1]['online_cum']:.1%}（累计 {len(rewards_seen)} 次调用）")

    # ---- baseline：各臂在保留集上的独立表现 ----
    print("\n评估 baseline（各臂在保留集上的表现）...")
    baseline = {}
    for a in ARMS:
        baseline[a["name"]] = evaluate(models, args.model, a, test, args.mock)
        print(f"  固定臂 {a['name']:13s}: {baseline[a['name']]:.1%}")
    oracle = max(baseline, key=baseline.get)
    random_exp = statistics.mean(baseline.values())
    final = history[-1]["heldout_acc"]
    online_final = history[-1]["online_cum"]
    first_round_online = history[0]["online_cum"]
    n_exp = con.execute("SELECT COUNT(*) FROM experience").fetchone()[0]
    arm_rows = list(con.execute("SELECT arm, COUNT(*), AVG(score), AVG(latency_s) FROM experience GROUP BY arm"))
    con.close()

    # ---- results.md ----
    L = []
    L.append("# 作业二 · 最小 RSL 系统运行结果\n")
    L.append("## 0. 实验设置\n")
    L.append(f"- 执行后端：本地 Ollama（{'模拟模型' if args.mock else '真实模型'}）")
    L.append(f"- 可学习的臂（= 模型路由策略）：" + "；".join(f"`{a['name']}`（{a['desc']}）" for a in ARMS))
    L.append(f"- 任务池：训练 {len(train)} 题 / 保留 {len(test)} 题，答案由程序生成、唯一正确")
    L.append(f"- 学习算法：UCB1（c=1.2），轮次 {args.rounds}，每轮 {args.samples} 个训练样本")
    L.append(f"- 经验库：{n_exp} 条记录（experience.db）")
    L.append(f"- 总耗时：{time.time() - t0:.0f} 秒\n")
    L.append("## 1. 学习曲线 A：在线累计准确率（模拟「边做边学」的实际表现）\n")
    L.append("| 轮次 | 累计调用次数 | 在线累计准确率 | 当前最佳臂 | 保留集准确率 |")
    L.append("|---|---|---|---|---|")
    for h in history:
        L.append(f"| {h['round']} | {h['pulls']} | **{h['online_cum']:.1%}** | `{h['best_arm']}` | {h['heldout_acc']:.1%} |")
    L.append("")
    gain_online = online_final - first_round_online
    L.append(f"第 1 轮 {first_round_online:.1%} → 最后一轮 {online_final:.1%}"
             f"（变化 {gain_online * 100:+.1f} 个百分点）。在线累计值会被早期的强制探索拉低，"
             "随后逐渐向较优臂收敛；更干净的效果证据见第 3 节与随机策略的对比。\n")
    L.append("## 2. 学习曲线 B：保留集准确率（模型没见过的题，检验泛化）\n")
    L.append("| 轮次 | 当前最佳臂 | 保留集准确率 |")
    L.append("|---|---|---|")
    for h in history:
        L.append(f"| {h['round']} | `{h['best_arm']}` | {h['heldout_acc']:.1%} |")
    L.append("")
    L.append("## 3. 与 baseline 对比（保留集）\n")
    L.append("| 策略 | 保留集准确率 |")
    L.append("|---|---|")
    L.append(f"| 随机选臂（各臂平均） | {random_exp:.1%} |")
    for a in ARMS:
        mark = " ← 事后最优单臂" if a["name"] == oracle else ""
        L.append(f"| 固定使用 `{a['name']}` | {baseline[a['name']]:.1%}{mark} |")
    L.append(f"| **RSL（学完之后选中的臂）** | **{final:.1%}** |")
    L.append("")
    L.append(f"相对随机策略 **{final - random_exp:+.1%}**；相对事后最优单臂 **{final - baseline[oracle]:+.1%}**"
             "（≥0 说明学到的策略不劣于事后最优）。\n")
    L.append("## 4. 各臂被选择的次数与实测成本\n")
    L.append("| 臂 | 被选择次数 | 平均得分 | 平均耗时 (s) |")
    L.append("|---|---|---|---|")
    for name, cnt, avg, lat in arm_rows:
        L.append(f"| `{name}` | {cnt} | {avg:.1%} | {lat:.1f} |")
    L.append("")
    L.append("## 5. 结论\n")
    L.append(f"- 系统在不依赖人工规则的前提下，自行发现 `{history[-1]['best_arm']}` 是更优策略："
             f"该臂在保留集上达到 {final:.1%}，随机选臂仅 {random_exp:.1%}。")
    L.append("- 学习机制：每次调用的机器判分结果作为 reward 写入经验库（{} 条），".format(n_exp)
             + "UCB1 用「历史均值 + 探索奖励」决定下一次选哪个臂，因此表现为「先试错、后收敛」；"
             + "在线累计准确率由 {:.1%} 变为 {:.1%}。".format(first_round_online, online_final))
    L.append("- 局限：① 任务类型限于可机器判定的数值/抽取题；② reward 依赖标准答案，开放式任务需要引入 "
             "LLM 裁判（如 Jev 这类廉价校准模型，$0.042/百万输入 token、输出免费）；"
             "③ 未考虑成本约束（只优化准确率），实际路由器还需在准确率与延迟/费用之间权衡。")
    with open(os.path.join(args.outdir, "results.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(L) + "\n")

    # ---- curve.svg：画在线累计准确率 ----
    W, H, PAD = 660, 380, 60
    xs = [PAD + i * (W - 2 * PAD) / max(1, len(history) - 1) for i in range(len(history))]
    vals = [h["online_cum"] for h in history]
    lo, hi = min(min(vals), 0.0), max(max(vals), 1.0)
    span = max(hi - lo, 0.05)
    ys = [H - PAD - (v - lo) / span * (H - 2 * PAD) for v in vals]
    pts = " ".join(f"{x:.1f},{y:.1f}" for x, y in zip(xs, ys))
    dots = "".join(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="4" fill="#1f6feb"/>' for x, y in zip(xs, ys))
    labels = "".join(
        f'<text x="{x:.1f}" y="{y - 10:.1f}" font-size="11" text-anchor="middle" fill="#1f6feb">{v:.0%}</text>'
        for x, y, v in zip(xs, ys, vals))
    grid = ""
    for i in range(6):
        frac = lo + span * i / 5
        yy = H - PAD - (frac - lo) / span * (H - 2 * PAD)
        grid += (f'<line x1="{PAD}" y1="{yy:.1f}" x2="{W - PAD}" y2="{yy:.1f}" stroke="#e5e7eb"/>'
                 f'<text x="{PAD - 10}" y="{yy + 4:.1f}" font-size="11" text-anchor="end" fill="#6b7280">{frac:.0%}</text>')
    xlabels = "".join(f'<text x="{x:.1f}" y="{H - PAD + 20}" font-size="11" text-anchor="middle" fill="#6b7280">R{i + 1}</text>'
                      for i, x in enumerate(xs))
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">'
           f'<rect width="{W}" height="{H}" fill="#ffffff"/>{grid}'
           f'<polyline points="{pts}" fill="none" stroke="#1f6feb" stroke-width="2.5"/>{dots}{labels}{xlabels}'
           f'<text x="{W / 2}" y="24" font-size="14" text-anchor="middle" fill="#111827">'
           f'Online cumulative accuracy vs. learning round</text>'
           f'<text x="{W / 2}" y="{H - 12}" font-size="12" text-anchor="middle" fill="#6b7280">learning round</text></svg>')
    with open(os.path.join(args.outdir, "curve.svg"), "w", encoding="utf-8") as fh:
        fh.write(svg)

    print(f"\n已输出：{os.path.join(args.outdir, 'results.md')} / curve.svg / experience.db")
    return 0


if __name__ == "__main__":
    sys.exit(main())
